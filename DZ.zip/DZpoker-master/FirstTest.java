package com.thoughtworks;

import java.io.Console;

import org.junit.Assert;
import org.junit.Test;

public class FirstTest {
    @Test
    public void test1(){//ͬ��˳
    	TexasHoldem th = new TexasHoldem();
        String result1 = th.judgeType("5S 6S 7S 8S 9S");
        Assert.assertEquals("StraightFlush",result1);
    }
    @Test
    public void test2(){//��«
    	TexasHoldem th = new TexasHoldem();
        String result1 = th.judgeType("3H AS AD AC AH");
        Assert.assertEquals("FourOfAKind",result1);
    }
    @Test
    public void test3(){//��֧
    	TexasHoldem th = new TexasHoldem();
        String result1 = th.judgeType("6D 6S 9H 9D 9S");
        Assert.assertEquals("FullHouse",result1);
    }
    @Test
    public void test4(){//ͬ��
    	TexasHoldem th = new TexasHoldem();
        String result1 = th.judgeType("2S 3S 5S 7S 9S");
        Assert.assertEquals("Flush",result1);
    }
    @Test
    public void test5(){//˳��
    	TexasHoldem th = new TexasHoldem();
        String result1 = th.judgeType("5S 6S 7S 8C 9S");
        Assert.assertEquals("Straight",result1);
    }
    @Test
    public void test6(){//����
    	TexasHoldem th = new TexasHoldem();
        String result1 = th.judgeType("5S 6S 9C 9D 9S");
        Assert.assertEquals("ThreeOfAKind",result1);
    }
    @Test
    public void test7(){//����
    	TexasHoldem th = new TexasHoldem();
        String result1 = th.judgeType("5S 7D 7S 9D 9S");
        Assert.assertEquals("TwoPair",result1);
    }
    @Test
    public void test8(){//����
    	TexasHoldem th = new TexasHoldem();
        String result1 = th.judgeType("5S 6S 7S 9D 9S");
        Assert.assertEquals("OnePair",result1);
    }
    @Test
    public void test9(){//ɢ��
    	TexasHoldem th = new TexasHoldem();
        String result1 = th.judgeType("5S 4C JH 7D 9S");
        Assert.assertEquals("HighCard",result1);
    }
}
